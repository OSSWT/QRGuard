"""Semantic Training implementation."""
