"""Structural Training implementation."""
